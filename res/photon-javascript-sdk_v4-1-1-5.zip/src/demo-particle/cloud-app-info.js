﻿
var AppInfo = {
//	Wss: true,	
    AppId: "<no-app-id>",
    AppVersion: "1.0",
//    FbAppId: "you fb app id", 
}

