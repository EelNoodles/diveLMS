﻿
var AppInfo = {
//	Wss: true,
    AppId: "<no-app-id>",
    AppVersion: "1.0"
}

